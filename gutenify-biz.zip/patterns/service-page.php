<?php
 /**
  * Title: Service Page
  * Slug: gutenify-biz/service-page
  * Categories: gutenify-biz
  */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"0"}},"className":"has-no-underline","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-no-underline">
    <!-- wp:pattern {"slug":"gutenify-biz/cover-with-post-title"} /-->
    <!-- wp:pattern {"slug":"gutenify-biz/service"} /-->
</div>
<!-- /wp:group -->

