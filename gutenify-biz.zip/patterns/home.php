<?php
 /**
  * Title: Home
  * Slug: gutenify-biz/home
  * Categories: gutenify-biz
  */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"0"}},"className":"has-no-underline","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-no-underline">
<!-- wp:pattern {"slug":"gutenify-biz/feature-banner"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/service"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/hero-section"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/portfolio"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/call-to-action"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/video-content"} /-->
<!-- wp:pattern {"slug":"gutenify-biz/latest-news"} /-->
</div>
<!-- /wp:group -->

